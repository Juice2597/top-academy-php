<?php
include '../templates/pages-template-2.phtml';