<?php
include '../templates/pages-template-1.phtml';