<?php
include '../templates/pages-template-3.phtml';